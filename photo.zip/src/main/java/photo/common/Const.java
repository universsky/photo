package photo.common;

/**
 * 
 */

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 * @author chenguangjian 2015年3月19日 下午5:26:02
 */
public class Const {
	public static final String TIMESTAMP = new SimpleDateFormat("yyyy-MM-dd")
			.format(new Date());
	public static final String BLOG_TITLE_SEO = "（ 微信公众号：光影人像 ）";
	public static final String BLOG_FOOTER_SEO = "<br><br><br>我们从来只做一件事,分享.<br>让美在这个世界流转<br>让倍感无趣的 受伤的 彷徨的 孤独的 或是心情忧郁的 人生黯淡的人们<br>能有一次机会<br>去再一次发现这个世界的美<br>并把美传递给他人<br><a href=\"http://weixin.sogou.com/gzh?openid=oIWsFtyCv9vFO5LtQh2UGt6AKl5U\"><br>去看看——微信公众号:光影人像</a><br><img src=\"http://img2.ph.126.net/uMELwhOXFuT70FFOduTvTQ==/6630561990350136164.jpg\"><br>扫码关注公众号<br><br>人生不过 浮光掠影<br>芸芸众生 人来人往<br>一切皆为 梦幻虚像<br><a href=\"http://652087.jwappgc.com/app/down/652087\">光影人像APP下载</a><br><a href=\"http://weidian.com/?userid=248695437\">ROSI中国：海量高清rosi写真系列</a><br><br>";
}
